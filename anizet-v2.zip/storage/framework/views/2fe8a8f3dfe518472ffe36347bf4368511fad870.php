<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-8">

        <video data-volume=".5" data-skin="dark" class="afterglow w-100" id="myvideo" width="1280" height="720" label="SD">

            <source src="<?php echo e($link); ?>" type="video/mp4" >
             <?php if($vid->path_id != null): ?>
                <track class="bg-dark text-dark" kind="captions" label="English" srclang="en" src="<?php echo e($sub); ?>" default>
             <?php endif; ?>
            <a href="<?php echo e($link); ?>" download>Download</a>

        </video>

<!-- Skip intro -->
        <div class="w-100 bg-dark p-3" id="btns">
            <button class="btn btn-warning uk-animation uk-animation-slide-top-small w-100" id="skip-intro">Эхлэл алгасах</button>

        </div>
    </div>
    <div class="col-md-3">
        <div class="accordion" id="accordionExample1">



            <div id="collapseOne" class="collapse hide" aria-labelledby="headingOne" data-parent="#accordionExample1">
                <div class="overflow-auto episode-box p-3" style="height:720px">
                    <?php $__currentLoopData = $animes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('p/'.$anime->id)); ?>"><p class="text-center ep-item"><span class="info-caption"><?php echo e($anime->caption); ?>:</span> <?php echo e($anime->season); ?></p></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button class="btn btn-warning w-100" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            Бусад Ангиуд (<?php echo e(count($episodes)); ?>)
            </button>
            </div>
        </div>
        <div class="accordion" id="accordionExample2">

            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample2">
                <button class="btn btn-warning w-100" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            Бусад Анимэ жагсаалт (<?php echo e(count($animes)); ?>)
            </button>
                <div class="overflow-auto episode-box p-3" style="height:720px">
                    <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('v/'.$episode->id)); ?>"><p class="<?php if($vid->episode == $episode->episode): ?> bg-light text-dark <?php elseif($vid->id != $episode->id): ?> bg-dark text-light <?php endif; ?>  text-center ep-item"><span class="info-caption">Анги:</span> <?php echo e($episode->episode); ?></p></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    var video = document.getElementById('myvideo');
    var button = document.getElementById("skip-intro");

    button.addEventListener("click", function(e) {
        console.log(video.duration);
        video.play();
        video.pause();
        video.currentTime = <?php echo e($vid->skip_intro); ?>;
        video.play();
    });

    </script>



<script src="//cdn.jsdelivr.net/npm/afterglowplayer@1.x"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\anizet-v2\resources\views/videos/show.blade.php ENDPATH**/ ?>