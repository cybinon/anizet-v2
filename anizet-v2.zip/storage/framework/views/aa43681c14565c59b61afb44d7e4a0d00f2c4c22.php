<?php $__env->startSection('content'); ?>
<?php if(count($anime)!=0): ?>
    <div class="uk-heading-medium  text-center">
        <p class="uk-h2 uk-heading-divider">Сүүлд гарсан цуврал</p>
    </div>
    <div class="owl-carousel owl-theme w-100" id="series">
        <?php $__currentLoopData = $anime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="uk-card uk-card-hover uk-transition-toggle" tabindex="0">
                <a href="/p/<?php echo e($item->id); ?>" class="uk-text-center">
                    <img style="width:100%" src="storage/<?php echo e($item->image); ?>" alt="">
                    <div class="uk-position-bottom uk-overlay uk-overlay-primary">
                        <p style="height:60px" class="uk-h5 uk-margin-remove uk-text-capitalize"><?php echo e($item->caption); ?></p>
                    </div>
                    <div class="uk-transition-fade uk-position-cover uk-position-small uk-overlay uk-overlay-default uk-flex uk-flex-center uk-flex-middle">
                            <p class="uk-h4 text-dark uk-margin-remove"><i class="fa fa-play fa-2x" aria-hidden="true"></i></p>
                        </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
<?php if(count($movie)!=0): ?>
        <div class="uk-heading-medium  text-center">
            <p class="uk-h2 uk-heading-divider">Нэг Ангит болон Кино</p>
        </div>
        <div class="owl-carousel owl-theme" id="movie">

            <?php $__currentLoopData = $movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="uk-card uk-card-hover uk-transition-toggle" tabindex="0">
                <a href="#" class="uk-text-center">
                    <img style="width:100%" src="storage/<?php echo e($item->image); ?>" alt="">
                    <div class="uk-position-bottom uk-overlay uk-overlay-primary">
                        <p style="height:60px" class="uk-h5 uk-margin-remove uk-text-capitalize"><?php echo e($item->caption); ?></p>
                    </div>
                    <div class="uk-transition-fade uk-position-cover uk-position-small uk-overlay uk-overlay-default uk-flex uk-flex-center uk-flex-middle">
                            <p class="uk-h4 text-dark uk-margin-remove"><i class="fa fa-play fa-2x" aria-hidden="true"></i></p>
                        </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
<?php endif; ?>

<?php if(count($song)!=0): ?>

        <div class="uk-heading-medium  text-center">
            <p class="uk-h2 uk-heading-divider">Дуу хөгжим</p>
        </div>

        <div class="owl-carousel owl-theme w-100" id="music">
            <?php $__currentLoopData = $song; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="uk-card uk-card-hover uk-transition-toggle" tabindex="0">
                    <a href="#" class="uk-text-center">
                        <img style="width:100%" src="storage/<?php echo e($item->image); ?>" alt="">
                        <div class="uk-position-bottom uk-overlay uk-overlay-primary">
                            <p style="height:60px" class="uk-h5 uk-margin-remove uk-text-capitalize"><?php echo e($item->caption); ?></p>
                        </div>
                        <div class="uk-transition-fade uk-position-cover uk-position-small uk-overlay uk-overlay-default uk-flex uk-flex-center uk-flex-middle">
                                <p class="uk-h4 text-dark uk-margin-remove"><i class="fa fa-play fa-2x" aria-hidden="true"></i></p>
                            </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
<?php endif; ?>
<?php if(count($manga)!=0): ?>
            <div class="uk-heading-medium  text-center">
                <p class="uk-h2 uk-heading-divider">Манай бүх сан</p>
            </div>

            <div class="owl-carousel owl-theme w-100" id="manga">
                <?php $__currentLoopData = $manga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="uk-card uk-card-hover uk-transition-toggle" tabindex="0">
                        <a href="#" class="uk-text-center">
                            <img style="width:100%" src="storage/<?php echo e($item->image); ?>" alt="">
                            <div class="uk-position-bottom uk-overlay uk-overlay-primary">
                                <p style="height:60px" class="uk-h5 uk-margin-remove uk-text-capitalize"><?php echo e($item->caption); ?></p>
                            </div>
                            <div class="uk-transition-fade uk-position-cover uk-position-small uk-overlay uk-overlay-default uk-flex uk-flex-center uk-flex-middle">
                                    <p class="uk-h4 text-dark uk-margin-remove"><i class="fa fa-play fa-2x" aria-hidden="true"></i></p>
                                </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\anizet-v2\resources\views/main.blade.php ENDPATH**/ ?>