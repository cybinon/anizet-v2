<?php $__env->startSection('content'); ?>

<div id="my-id" uk-modal>
    <div class="uk-modal-dialog uk-modal-body">
        <h2 class="uk-modal-title">Танилцуулга бичлэг</h2>
        <iframe width="100%" height="320" src="https://www.youtube.com/embed/<?php echo e($post->trailer); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
</div>

<div class="uk-h1 text-center"><?php echo e($post->caption); ?></div>
<hr>

<div class="row">
    <div class="col-md-3">
        <img class="w-100" src="/storage/<?php echo e($post->image); ?>" alt="">
        <hr>
    </div>
    <div class="col-md-3">
        <div class="accordion" id="accordionExample">

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
            <p><span class="info-caption">Бүлэг:</span> <?php echo e($post->season); ?></p>
            <p><span class="info-caption">Нийт анги:</span> <?php echo e($post->episodes); ?></p>
            <p><span class="info-caption">Насны ангилал:</span> <?php echo e($post->pg); ?></p>
            <p><span class="info-caption">Төлөв:</span>
                <?php switch($post->status):
                    case (1): ?>
                        <span class="btn btn-warning">Гарч байгаа</span>
                        <?php break; ?>
                    <?php case (2): ?>
                        <span class="btn btn-success">Дууссан</span>
                        <?php break; ?>
                    <?php case (3): ?>
                       <span class="btn btn-danger">Хаягдсан</span>
                        <?php break; ?>

                    <?php default: ?>
                        <span class="btn btn-warning">Гарч байгаа</span>
                <?php endswitch; ?>
            </p>

            <p><span class="info-caption">Товч агуулга:</span> <?php echo e($post->info); ?></p>
            <p class="text-center"><button class="btn btn-primary w-100" uk-toggle="target: #my-id" type="button" ><i class="fas fa-play-circle fa-2x"></i></button></p>
            <hr>
    </div>
  </div>
  <div class="accordion" id="accordionExample1">

        <button class="btn btn-warning w-100" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Анимэ үзэх / Товч мэдээлэл
        </button>

    <div id="collapseOne" class="collapse hide" aria-labelledby="headingOne" data-parent="#accordionExample1">
    <div class="overflow-auto episode-box p-3">
            <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('v/'.$episode->id)); ?>"><p class="bg-light text-dark text-center ep-item"><span class="info-caption">Анги:</span> <?php echo e($episode->episode); ?></p></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    </div>
    <hr>
  </div>


        </div>

        <div class="col-md-6">
            <div class="overflow-auto episode-box p-3">
                <?php if(count($season)> 1): ?>
                <h2 class="text-center">Бусад бүлэг</h2>
                <hr>
                <div class="owl-carousel owl-theme w-100" id="season">
                    <?php $__currentLoopData = $season; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->id != $post->id): ?>
                    <div class="uk-card uk-card-hover uk-transition-toggle" tabindex="0">
                            <a href="<?php echo e(url('p/'.$item->id)); ?>" class="uk-text-center">
                                <img style="width:100%" src="<?php echo e(url('storage/'.$item->image)); ?>" alt="">
                                <div class="uk-position-bottom uk-overlay uk-overlay-primary">
                                    <p style="height:60px" class="uk-h5 uk-margin-remove"><?php echo e($item->caption); ?></p>
                                </div>
                                <div class="uk-transition-fade uk-position-cover uk-position-small uk-overlay uk-overlay-default uk-flex uk-flex-center uk-flex-middle">
                                        <p class="uk-h4 text-dark uk-margin-remove"><i class="fa fa-play fa-2x" aria-hidden="true"></i></p>
                                    </div>
                            </a>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <hr>
                <?php endif; ?>
                <h2 class="text-center">Бусад Анимэ</h2>
                <hr>
               <div class="owl-carousel owl-theme w-100" id="series">
        <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="uk-card uk-card-hover uk-transition-toggle" tabindex="0">
                <a href="<?php echo e(url('p/'.$item->id)); ?>" class="uk-text-center">
                    <img style="width:100%" src="<?php echo e(url('storage/'.$item->image)); ?>" alt="">
                    <div class="uk-position-bottom uk-overlay uk-overlay-primary">
                        <p style="height:60px" class="uk-h5 uk-margin-remove"><?php echo e($item->caption); ?></p>
                    </div>
                    <div class="uk-transition-fade uk-position-cover uk-position-small uk-overlay uk-overlay-default uk-flex uk-flex-center uk-flex-middle">
                            <p class="uk-h4 text-dark uk-margin-remove"><i class="fa fa-play fa-2x" aria-hidden="true"></i></p>
                        </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\anizet-v2\resources\views/posts/show.blade.php ENDPATH**/ ?>